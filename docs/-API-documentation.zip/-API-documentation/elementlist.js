
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","SNTools\\NotImplementedException"],["c","SNTools\\Object"],["c","SNTools\\PropertyException"]];
